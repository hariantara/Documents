function perkalian2(num, numb){
  if(num == 2){//sebagain counter
    return 2;//sebagai cunter dimana
  }
  else{
    return num * perkalian2(num-5, numb);//num-5 sebagai pengurang
  }
}
console.log(perkalian2(12,5));
